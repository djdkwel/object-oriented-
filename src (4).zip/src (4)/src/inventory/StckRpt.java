package inventory;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class StckRpt {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StckRpt window = new StckRpt();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StckRpt() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		frame.getContentPane().setForeground(new Color(51, 51, 51));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(51, 51, 51));
		panel.setBounds(0, 88, 225, 370);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		//ADD STOCK BUTTON
		JPanel addItem_button = new JPanel();
		addItem_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		addItem_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				addItem_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				addItem_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				AddStock addStck = new AddStock();
				frame.dispose();
			}
		});
		addItem_button.setBackground(new Color(0, 204, 204));
		addItem_button.setBounds(0, 76, 225, 53);
		panel.add(addItem_button);
		addItem_button.setLayout(null);
		
		JLabel lblAddItem = new JLabel("Add Item");
		lblAddItem.setForeground(new Color(255, 255, 255));
		lblAddItem.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblAddItem.setBounds(65, 11, 93, 32);
		addItem_button.add(lblAddItem);
		
		
		//REMOVE ITEM BUTTON
		JPanel remItem_button = new JPanel();
		remItem_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		remItem_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				remItem_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				remItem_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				RemStck remve = new RemStck();
				frame.dispose();
			}
		});
		remItem_button.setBackground(new Color(0, 204, 204));
		remItem_button.setLayout(null);
		remItem_button.setBounds(0, 140, 225, 53);
		panel.add(remItem_button);
		
		JLabel lblRemItem = new JLabel("Remove Item");
		lblRemItem.setForeground(new Color(255, 255, 255));
		lblRemItem.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblRemItem.setBounds(55, 11, 127, 32);
		remItem_button.add(lblRemItem);
		
		//STOCK REPORT BUTTON (NOT IN ACTION)
		JPanel stckRpt_button = new JPanel();
		stckRpt_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		stckRpt_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				stckRpt_button.setBackground(new Color(20, 20, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				stckRpt_button.setBackground(new Color(20, 20, 20));
			}
		});
		stckRpt_button.setBackground(new Color(20, 20, 20));
		stckRpt_button.setLayout(null);
		stckRpt_button.setBounds(0, 207, 225, 53);
		panel.add(stckRpt_button);
		
		JLabel lblStckRpt = new JLabel("Stock Report");
		lblStckRpt.setForeground(new Color(255, 255, 255));
		lblStckRpt.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblStckRpt.setBounds(55, 11, 115, 32);
		stckRpt_button.add(lblStckRpt);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(51, 51, 51));
		panel_1.setBounds(0, 48, 856, 39);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Stock Report");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Dubai Medium", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(238, 11, 123, 17);
		panel_1.add(lblNewLabel_2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 0, 856, 48);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(StockSide.class.getResource("/images/twinng.png")));
		label.setBounds(20, 0, 89, 48);
		panel_2.add(label);
		
		JLabel lblJadanSoftwares = new JLabel("Fava Foods & Services\u00A9 ");
		lblJadanSoftwares.setFont(new Font("Dubai Light", Font.PLAIN, 16));
		lblJadanSoftwares.setBounds(420, 0, 185, 26);
		panel_2.add(lblJadanSoftwares);
		
		JLabel lblPlotNo = new JLabel("13 Gypsum Close, Eltham Park, Spanish Town, St. Catherine");
		lblPlotNo.setFont(new Font("Dubai Light", Font.PLAIN, 14));
		lblPlotNo.setForeground(new Color(51, 51, 51));
		lblPlotNo.setBounds(332, 23, 356, 14);
		panel_2.add(lblPlotNo);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(0, 459, 855, 10);
		frame.getContentPane().add(panel_3);
		
		//BACK BUTTON
		JPanel back_button = new JPanel();
		back_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				back_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				back_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				StockSide sSide = new StockSide();
				frame.dispose();
			}
		});
		back_button.setLayout(null);
		back_button.setBackground(new Color(0, 204, 204));
		back_button.setBounds(253, 418, 52, 30);
		frame.getContentPane().add(back_button);
		
		JLabel lblBack = new JLabel("back");
		lblBack.setForeground(Color.WHITE);
		lblBack.setFont(new Font("Century Gothic", Font.BOLD, 14));
		lblBack.setBounds(10, 0, 56, 32);
		back_button.add(lblBack);
		
		frame.setBounds(100, 100, 872, 508);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
