package inventory;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class RemStck {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RemStck window = new RemStck();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RemStck() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		frame.getContentPane().setForeground(new Color(51, 51, 51));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(51, 51, 51));
		panel.setBounds(0, 88, 225, 370);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		//ADD ITEM BUTTON
		JPanel addItem_button = new JPanel();
		addItem_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		addItem_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				addItem_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				addItem_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				AddStock stck = new AddStock();
				frame.dispose();
			}
		});
		addItem_button.setBackground(new Color(0, 204, 204));
		addItem_button.setBounds(0, 76, 225, 53);
		panel.add(addItem_button);
		addItem_button.setLayout(null);
		
		JLabel lblAddItem = new JLabel("Add Item");
		lblAddItem.setForeground(new Color(255, 255, 255));
		lblAddItem.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblAddItem.setBounds(65, 11, 93, 32);
		addItem_button.add(lblAddItem);
		
		//REMOVE STOCK BUTTON (NOT IN ACTION)
		JPanel remItem_button = new JPanel();
		remItem_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		remItem_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				remItem_button.setBackground(new Color(20, 20, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				remItem_button.setBackground(new Color(20, 20, 20));
			}
		});
		remItem_button.setBackground(new Color(20, 20, 20));
		remItem_button.setLayout(null);
		remItem_button.setBounds(0, 140, 225, 53);
		panel.add(remItem_button);
		
		JLabel lblRemItem = new JLabel("Remove Item");
		lblRemItem.setForeground(new Color(255, 255, 255));
		lblRemItem.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblRemItem.setBounds(55, 11, 127, 32);
		remItem_button.add(lblRemItem);
		
		//STOCK REPORT BUTTON
		JPanel stockRpt_button = new JPanel();
		stockRpt_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		stockRpt_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				stockRpt_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				stockRpt_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				StckRpt rpt = new StckRpt();
				frame.dispose();
			}
		});
		stockRpt_button.setBackground(new Color(0, 204, 204));
		stockRpt_button.setLayout(null);
		stockRpt_button.setBounds(0, 207, 225, 53);
		panel.add(stockRpt_button);
		
		JLabel lblStockRpt = new JLabel("Stock Report");
		lblStockRpt.setForeground(new Color(255, 255, 255));
		lblStockRpt.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblStockRpt.setBounds(55, 11, 115, 32);
		stockRpt_button.add(lblStockRpt);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(51, 51, 51));
		panel_1.setBounds(0, 48, 856, 39);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Remove Item");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Dubai Medium", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(238, 11, 123, 17);
		panel_1.add(lblNewLabel_2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 0, 856, 48);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(StockSide.class.getResource("/images/twinng.png")));
		label.setBounds(20, 0, 89, 48);
		panel_2.add(label);
		
		JLabel lblJadanSoftwares = new JLabel("Fava Foods & Services\u00A9 ");
		lblJadanSoftwares.setFont(new Font("Dubai Light", Font.PLAIN, 16));
		lblJadanSoftwares.setBounds(420, 0, 185, 26);
		panel_2.add(lblJadanSoftwares);
		
		JLabel lblPlotNo = new JLabel("13 Gypsum Close, Eltham Park, Spanish Town, St. Catherine");
		lblPlotNo.setFont(new Font("Dubai Light", Font.PLAIN, 14));
		lblPlotNo.setForeground(new Color(51, 51, 51));
		lblPlotNo.setBounds(332, 23, 356, 14);
		panel_2.add(lblPlotNo);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(0, 459, 855, 10);
		frame.getContentPane().add(panel_3);
		
		
		//OKAY BUTTON
		JPanel ok_button = new JPanel();
		ok_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ok_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ok_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				//action for submitting
			}
		});
		ok_button.setLayout(null);
		ok_button.setBackground(new Color(0, 204, 204));
		ok_button.setBounds(571, 408, 70, 30);
		frame.getContentPane().add(ok_button);
		
		JLabel lblOk = new JLabel("OK");
		lblOk.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblOk.setForeground(Color.WHITE);
		lblOk.setFont(new Font("Century Gothic", Font.BOLD, 14));
		lblOk.setBounds(20, 0, 29, 32);
		ok_button.add(lblOk);
		
		
		//CANCEL BUTTON
		JPanel cancel_button = new JPanel();
		cancel_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		cancel_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				cancel_button.setBackground(new Color(240, 0, 0));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				cancel_button.setBackground(new Color(204, 0, 0));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				StockSide sSide = new StockSide();
				frame.dispose();
			}
		});
		cancel_button.setLayout(null);
		cancel_button.setBackground(new Color(204, 0, 0));
		cancel_button.setBounds(679, 408, 70, 30);
		frame.getContentPane().add(cancel_button);
		
		JLabel lblCancel = new JLabel("cancel");
		lblCancel.setForeground(Color.WHITE);
		lblCancel.setFont(new Font("Century Gothic", Font.BOLD, 14));
		lblCancel.setBounds(10, 0, 56, 29);
		cancel_button.add(lblCancel);
		
		frame.setBounds(100, 100, 872, 508);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
