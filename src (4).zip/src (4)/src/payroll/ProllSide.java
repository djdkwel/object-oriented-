package payroll;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

import access.Welcome;
import inventory.StockSide;


public class ProllSide {

	private JFrame frame;
	private JTextField txt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProllSide window = new ProllSide();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ProllSide() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		frame.getContentPane().setForeground(new Color(51, 51, 51));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(51, 51, 51));
		panel.setBounds(0, 88, 225, 370);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		//BUTTON FOR ADD EMPLOYEE
		JPanel newEmp_button = new JPanel();
		newEmp_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		newEmp_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				newEmp_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				newEmp_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				AddEmp newEmp = new AddEmp();
				frame.dispose();
			}
		});
		newEmp_button.setBackground(new Color(0, 204, 204));
		newEmp_button.setBounds(0, 76, 225, 53);
		panel.add(newEmp_button);
		newEmp_button.setLayout(null);
		
		JLabel lblNewEmployee = new JLabel("New Employee");
		lblNewEmployee.setForeground(new Color(255, 255, 255));
		lblNewEmployee.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblNewEmployee.setBounds(47, 11, 133, 32);
		newEmp_button.add(lblNewEmployee);
		
		
		//BUTTON FOR EMPLOYEE REPORT
		JPanel empRept_button = new JPanel();
		empRept_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		empRept_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				empRept_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				empRept_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				EmpRpt newEmp = new EmpRpt();
				frame.dispose();
			}
		});
		empRept_button.setBackground(new Color(0, 204, 204));
		empRept_button.setLayout(null);
		empRept_button.setBounds(0, 140, 225, 53);
		panel.add(empRept_button);
		
		JLabel lblEmployeeReport = new JLabel("Employee Report");
		lblEmployeeReport.setForeground(new Color(255, 255, 255));
		lblEmployeeReport.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblEmployeeReport.setBounds(36, 11, 156, 32);
		empRept_button.add(lblEmployeeReport);
		
		//PAYSLIP BUTTON
		JPanel paySlip_button = new JPanel();
		paySlip_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		paySlip_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				paySlip_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				paySlip_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				Payslip newEmp = new Payslip();
				frame.dispose();
			}
		});
		paySlip_button.setBackground(new Color(0, 204, 204));
		paySlip_button.setLayout(null);
		paySlip_button.setBounds(0, 207, 225, 53);
		panel.add(paySlip_button);
		
		JLabel lblPayslip = new JLabel("Payslip");
		lblPayslip.setForeground(new Color(255, 255, 255));
		lblPayslip.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblPayslip.setBounds(78, 11, 69, 32);
		paySlip_button.add(lblPayslip);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(51, 51, 51));
		panel_1.setBounds(0, 48, 856, 39);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Payroll");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Dubai Medium", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(238, 11, 60, 17);
		panel_1.add(lblNewLabel_2);
		
		txt = new JTextField();
		txt.setFont(new Font("Century Gothic", Font.PLAIN, 12));
		txt.setForeground(new Color(153, 153, 153));
		txt.setColumns(10);
		txt.setBounds(675, 11, 143, 20);
		panel_1.add(txt);
		
		JLabel lblthisIsA = new JLabel("Employee Payroll");
		lblthisIsA.setFont(new Font("Trebuchet MS", Font.BOLD, 56));
		lblthisIsA.setForeground(new Color(0, 204, 204));
		lblthisIsA.setBounds(316, 118, 508, 100);
		frame.getContentPane().add(lblthisIsA);
		
		JLabel lblNewLabel = new JLabel("Choose from any of the options ");
		lblNewLabel.setFont(new Font("Dubai Light", Font.PLAIN, 30));
		lblNewLabel.setBounds(350, 198, 435, 86);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblOnTheLeft = new JLabel("on the left");
		lblOnTheLeft.setFont(new Font("Dubai Light", Font.PLAIN, 30));
		lblOnTheLeft.setBounds(489, 268, 137, 39);
		frame.getContentPane().add(lblOnTheLeft);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 0, 856, 48);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(StockSide.class.getResource("/images/twinng.png")));
		label.setBounds(20, 0, 89, 48);
		panel_2.add(label);
		
		JLabel lblJadanSoftwares = new JLabel("Fava Foods & Services\u00A9 ");
		lblJadanSoftwares.setFont(new Font("Dubai Light", Font.PLAIN, 16));
		lblJadanSoftwares.setBounds(420, 0, 185, 26);
		panel_2.add(lblJadanSoftwares);
		
		JLabel lblPlotNo = new JLabel("13 Gypsum Close, Eltham Park, Spanish Town, St. Catherine");
		lblPlotNo.setFont(new Font("Dubai Light", Font.PLAIN, 14));
		lblPlotNo.setForeground(new Color(51, 51, 51));
		lblPlotNo.setBounds(332, 23, 356, 14);
		panel_2.add(lblPlotNo);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(ProllSide.class.getResource("/images/studicons-chevron-left.png")));
		lblNewLabel_1.setBounds(485, 308, 94, 94);
		frame.getContentPane().add(lblNewLabel_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(0, 459, 855, 10);
		frame.getContentPane().add(panel_3);
		
		//BACK BUTTON
		JPanel back_button = new JPanel();
		back_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				back_button.setBackground(new Color(30, 30, 30));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				back_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				Welcome wel = new Welcome();
				frame.dispose();
			}
		});
		back_button.setLayout(null);
		back_button.setBackground(new Color(0, 204, 204));
		back_button.setBounds(253, 418, 52, 30);
		frame.getContentPane().add(back_button);
		
		JLabel lblBack = new JLabel("back");
		lblBack.setForeground(Color.WHITE);
		lblBack.setFont(new Font("Century Gothic", Font.BOLD, 14));
		lblBack.setBounds(10, 0, 56, 32);
		back_button.add(lblBack);
		
		
		frame.setBounds(100, 100, 872, 508);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
