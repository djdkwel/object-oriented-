package access;

import javax.swing.JOptionPane;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.border.MatteBorder;

import access.Welcome;

import javax.swing.ImageIcon;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Panel;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LogIn extends javax.swing.JFrame{

	private JFrame frame;
	private JTextField txtUsrname;
	private JPasswordField passwordField;
	int attempt = 1;  //tracks attempts

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogIn window = new LogIn();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LogIn() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		frame.getContentPane().setForeground(new Color(51, 51, 51));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 153, 153));
		panel.setBounds(0, 0, 482, 469);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("New label");
		label.setIcon(new ImageIcon(LogIn.class.getResource("/images/ffs.png")));
		label.setBounds(-14, 32, 496, 162);
		panel.add(label);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(LogIn.class.getResource("/images/128-128-12bbf9db6249ac6adcc273a20d19bdee-food.png")));
		lblNewLabel.setBounds(27, 264, 145, 149);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(LogIn.class.getResource("/images/128-128-0f43ad237c666c8c587e295215c2a20a-food.png")));
		lblNewLabel_1.setBounds(177, 250, 129, 128);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(LogIn.class.getResource("/images/128-128-dc8401b4400c0249c70e4d8a443926ab-chicken.png")));
		lblNewLabel_2.setBounds(316, 261, 145, 163);
		panel.add(lblNewLabel_2);
		
		txtUsrname = new JTextField();
		txtUsrname.setBackground(new Color(255, 255, 255));
		txtUsrname.setBorder(null);
		txtUsrname.setFont(new Font("Century Gothic", Font.PLAIN, 14));
		txtUsrname.setHorizontalAlignment(SwingConstants.CENTER);
		txtUsrname.setToolTipText("");
		txtUsrname.setForeground(new Color(51, 51, 51));
		txtUsrname.setBounds(539, 176, 249, 33);
		frame.getContentPane().add(txtUsrname);
		txtUsrname.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(0, 204, 204));
		separator.setBounds(539, 211, 249, 12);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(new Color(0, 204, 204));
		separator_1.setBounds(539, 311, 249, 17);
		frame.getContentPane().add(separator_1);
		
		JLabel lblUsername = new JLabel("USERNAME");
		lblUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsername.setFont(new Font("Century Gothic", Font.BOLD, 14));
		lblUsername.setLabelFor(txtUsrname);
		lblUsername.setForeground(new Color(51, 51, 51));
		lblUsername.setBounds(625, 131, 74, 33);
		frame.getContentPane().add(lblUsername);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(new Color(255, 255, 255));
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setBorder(null);
		passwordField.setBounds(539, 277, 249, 33);
		frame.getContentPane().add(passwordField);
		
		JLabel lblPassword = new JLabel("PASSWORD");
		lblPassword.setForeground(new Color(51, 51, 51));
		lblPassword.setFont(new Font("Century Gothic", Font.BOLD, 14));
		lblPassword.setBounds(624, 233, 75, 33);
		frame.getContentPane().add(lblPassword);
		
		JLabel lblAdministrationLogin = new JLabel("ADMINISTRATION LOGIN");
		lblAdministrationLogin.setForeground(new Color(51, 51, 51));
		lblAdministrationLogin.setFont(new Font("Century Gothic", Font.BOLD, 24));
		lblAdministrationLogin.setBounds(530, 68, 285, 33);
		frame.getContentPane().add(lblAdministrationLogin);
		
		
		//Login Button
		Panel panel_1 = new Panel();
		JOptionPane optPane = new JOptionPane();
		
		panel_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		panel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				panel_1.setBackground(new Color(0, 180, 180));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				panel_1.setBackground(new Color(0, 204, 204));
			}
			
			//THIS DIRECTS THE USER TO WELCOME SCREEN
			@Override
			public void mouseClicked(MouseEvent e) {
				String password = passwordField.getText();
				String username = txtUsrname.getText();
				String crrctPwd = "admin10"; //correct password
				String crrctUsnm = "admin"; //correct username
				
				if (attempt <4 && password.equals(crrctPwd) && username.equals(crrctUsnm))
				{
					
					Welcome welc = new Welcome();
					frame.dispose();
				}
				
				else if(attempt != 3) 
				{
					optPane.showMessageDialog(null, "Incorrect credentials entered");
				
					
					txtUsrname.setText(null);
				}
				else //closes system if incorrect 3 times
				{
					optPane.showMessageDialog(null, "Attempts Exceeded");
					 System.exit(1); 
				}
				attempt++;
			}
		});
		panel_1.setBackground(new Color(0, 204, 204));
		panel_1.setBounds(605, 355, 114, 41);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblLogIn = new JLabel("Log in");
		lblLogIn.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		lblLogIn.setBounds(33, 11, 43, 17);
		panel_1.add(lblLogIn);
		//end of Login button
		
		frame.setBounds(100, 100, 872, 508);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
