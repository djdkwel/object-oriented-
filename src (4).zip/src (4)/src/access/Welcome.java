package access;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JSlider;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.SpringLayout;

import access.LogIn;
import inventory.StockSide;
import payroll.ProllSide;

public class Welcome extends javax.swing.JFrame {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Welcome window = new Welcome();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Welcome() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		frame.getContentPane().setForeground(new Color(51, 51, 51));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(51, 51, 51));
		panel.setBounds(0, 88, 225, 370);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBounds(0, 371, 855, 10);
		panel.add(panel_3);
		
		//PAYROLL SIDE BUTTON
		
		JPanel payroll_button = new JPanel();
		payroll_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		payroll_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				payroll_button.setBackground(new Color(25, 25, 25));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				payroll_button.setBackground(new Color(0, 204, 204));
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				ProllSide prollSd = new ProllSide();
				frame.dispose();
			}
		});
		payroll_button.setBorder(null);
		payroll_button.setBackground(new Color(0, 204, 204));
		payroll_button.setBounds(24, 41, 171, 130);
		panel.add(payroll_button);
		SpringLayout sl_payroll_button = new SpringLayout();
		payroll_button.setLayout(sl_payroll_button);
		
		JLabel lblPayroll = new JLabel("Payroll");
		sl_payroll_button.putConstraint(SpringLayout.NORTH, lblPayroll, 37, SpringLayout.NORTH, payroll_button);
		sl_payroll_button.putConstraint(SpringLayout.WEST, lblPayroll, 37, SpringLayout.WEST, payroll_button);
		sl_payroll_button.putConstraint(SpringLayout.EAST, lblPayroll, 138, SpringLayout.WEST, payroll_button);
		lblPayroll.setForeground(new Color(255, 255, 255));
		lblPayroll.setFont(new Font("Dubai Light", Font.BOLD, 30));
		payroll_button.add(lblPayroll);
		
		
		//INVENTORY SIDE BUTTON
		JPanel inv_button = new JPanel();
		inv_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		inv_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				inv_button.setBackground(new Color(25, 25, 25));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				inv_button.setBackground(new Color(0, 204, 204));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				StockSide stckSide = new StockSide();
				frame.dispose();
			}
		});
		inv_button.setLayout(null);
		inv_button.setBorder(null);
		inv_button.setBackground(new Color(0, 204, 204));
		inv_button.setBounds(24, 199, 171, 130);
		panel.add(inv_button);
		
		JLabel lblInventory = new JLabel("Inventory");
		lblInventory.setForeground(new Color(255, 255, 255));
		lblInventory.setFont(new Font("Dubai Light", Font.BOLD, 30));
		lblInventory.setBounds(21, 39, 140, 51);
		inv_button.add(lblInventory);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(51, 51, 51));
		panel_1.setBounds(0, 48, 856, 39);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Home");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Dubai Medium", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(238, 11, 60, 17);
		panel_1.add(lblNewLabel_2);
		
		
		//LOG OUT BUTTON
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LogIn log = new LogIn();
				frame.dispose();
			}
		});
		
		btnLogOut.setBorder(null);
		btnLogOut.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLogOut.setBackground(Color.WHITE);
		btnLogOut.setFont(new Font("Century Gothic", Font.PLAIN, 13));
		btnLogOut.setBounds(757, 10, 89, 23);
		panel_1.add(btnLogOut);
		
		JLabel lblthisIsA = new JLabel("Welcome");
		lblthisIsA.setFont(new Font("Trebuchet MS", Font.BOLD, 94));
		lblthisIsA.setForeground(new Color(0, 0, 0));
		lblthisIsA.setBounds(339, 121, 428, 100);
		frame.getContentPane().add(lblthisIsA);
		
		JLabel lblNewLabel = new JLabel("Choose from any of the options ");
		lblNewLabel.setFont(new Font("Dubai Light", Font.PLAIN, 30));
		lblNewLabel.setBounds(349, 204, 435, 86);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblOnTheLeft = new JLabel("on the left");
		lblOnTheLeft.setFont(new Font("Dubai Light", Font.PLAIN, 30));
		lblOnTheLeft.setBounds(488, 272, 137, 39);
		frame.getContentPane().add(lblOnTheLeft);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Welcome.class.getResource("/images/studicons-chevron-left.png")));
		lblNewLabel_1.setBounds(479, 331, 120, 85);
		frame.getContentPane().add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 0, 856, 48);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Welcome.class.getResource("/images/twinng.png")));
		label.setBounds(20, 0, 89, 48);
		panel_2.add(label);
		
		JLabel lblJadanSoftwares = new JLabel("Fava Foods & Services\u00A9 ");
		lblJadanSoftwares.setFont(new Font("Dubai Light", Font.PLAIN, 16));
		lblJadanSoftwares.setBounds(420, 0, 185, 26);
		panel_2.add(lblJadanSoftwares);
		
		JLabel lblPlotNo = new JLabel("13 Gypsum Close, Eltham Park, Spanish Town, St. Catherine");
		lblPlotNo.setFont(new Font("Dubai Light", Font.PLAIN, 14));
		lblPlotNo.setForeground(new Color(51, 51, 51));
		lblPlotNo.setBounds(332, 23, 356, 14);
		panel_2.add(lblPlotNo);
		
		
		frame.setBounds(100, 100, 872, 508);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
